package com.bootapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootapplicationApplication.class, args);
	}

}
