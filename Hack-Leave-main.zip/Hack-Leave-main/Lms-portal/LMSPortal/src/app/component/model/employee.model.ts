export class Employee{
    id?:number;
    name:string;
    startDate:string;
    endDate:string;
    leaveDays:number;
    leaveType:string;
    leaveReason:string;
    leaveStatus:string;
    leaveBalance:number;
}