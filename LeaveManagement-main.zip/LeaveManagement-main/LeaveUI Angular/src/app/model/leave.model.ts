export class Leave{
    id?: number;
    startDate: string;
    endDate: string;
    days: number;
    leaveType: string;
    leaveReason: string;
}