export class DataRequest{
    id?:number;
    status: string;
}