export class Status{
    id?: string;
    name: string;
    startDate: string;
    endDate: string;
    days: number;
    leaveType: string;
    leaveReason: string;
    status: string;
    employeeId: string;
}